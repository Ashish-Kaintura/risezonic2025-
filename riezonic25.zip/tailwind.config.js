export default {
  content: ["./index.html", "./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#0A192F",
        secondary: "#64FFDA",
        accent: "#233554",
        background: "#112240",
        text: "#8892B0",
        white: "#FFFFFF",
        black: "#000000",
      },
      fontSize: {
        42: "10.5rem",
        8: "7rem",
        128: "32rem",
        144: "36rem",
        160: "40rem",
        176: "44rem",
        192: "48rem",
      },
      width: {
        42: "11.5rem",
      },
      fontFamily: {
        heading: ["Poppins", "sans-serif"],
        body: ["Inter", "sans-serif"],
        detail: ["Roboto Mono", "monospace"],
      },
    },
  },
  plugins: [],
};
